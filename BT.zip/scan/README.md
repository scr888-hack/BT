Installation for Termux

$ apt update

$ apt upgrade

$ apt install python

$ apt install git

$ git clone https://github.com/Myyepz/NewSB

$ cd NewSB

$ python -m pip install -r requirements.txt

$ python3 sby.py

------------------------------

Installation for VPS

$ git clone https://github.com/Myyepz/NewSB

$ cd NewSB

$ python3 -m pip install -r requirements.txt

$ python3 sby.py

------------------------------

Rework By Yepz @Myyepz

Special Thanks:

LINE Square

HelloWorld Square

Discord

HelloWorld

Author

• Zero Cool / @crash-override404

• Fadhiil Rachman / @fadhiilrachman

• Alin / @muhmursalind

Support

All Hello World Members :

• Tanduri a.k.a HelloTan / @hellotan

• Fauzan Ardhana / @fauzanardh

• Moe Poi ~ / @moepoi

• Muhammad Fahri / @FAHRIZTX

• Dosugamea / @Dosugamea

• Dzin / @dzingans

And others.
